package com.freeranger.dark_caverns.blocks;

import net.minecraft.block.Block;

public class CrackedBedrockBlock extends Block {
    public CrackedBedrockBlock(Properties properties) {
        super(properties);
    }
}
