package com.freeranger.dark_caverns.blocks;

import net.minecraft.block.LanternBlock;

import net.minecraft.block.AbstractBlock.Properties;

public class LuminiteLanternBlock extends LanternBlock {
    public LuminiteLanternBlock(Properties properties) {
        super(properties);
    }
}
